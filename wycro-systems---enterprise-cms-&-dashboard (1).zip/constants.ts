
import { AppState, ThemeMode } from './types';

export const INITIAL_STATE: AppState = {
  content: {
    companyName: "주식회사 와이크로시스템즈",
    companyNameEn: "Wycro Systems",
    greetingTitle: "정교한 기술의 조화,\n미래 모빌리티의 본질을 설계하다",
    greetingContent: `안녕하세요.\n주식회사 와이크로시스템즈는 전기차용 배터리 및 오일 칠러 솔루션의 진화를 선도하는 기술 제조 파트너입니다.\n\n우리의 경쟁력은 '생각하는 제조'에서 시작됩니다. 단순히 공정을 수행하는 것을 넘어, 그 공정을 가장 완벽하게 구현할 수 있는 자동화 설비를 직접 설계하고 제작합니다. 현장에서 직접 검증한 독보적인 설비 기술력은 도장(표면처리)과 모듈화 생산 공정에 즉각 이식되어, 인력 의존도를 낮추고 품질의 일관성을 극대화합니다.\n\n와이크로시스템즈는 공정의 본질을 꿰뚫는 통찰력으로 고객사의 원가 절감과 생산 효율을 실현합니다. 기획부터 설비 구축, 그리고 최종 제품 양산까지 이어지는 수직 계열화된 원스톱 솔루션은 안정적인 생산 구조를 원하는 고객사에게 가장 신뢰할 수 있는 답이 될 것입니다.\n\n“기술을 만드는 설비, 가치를 생산하는 제조”\n와이크로시스템즈는 혁신적인 자동화 솔루션으로 고객사와 함께 더 높은 경쟁력을 향해 나아가겠습니다.\n\n감사합니다.`,
    phone: "010-2767-1924",
    address: "충남 천안시 동남구 풍세면 태학산로 175-1",
    email: "universe78@naver.com",
    establishedYear: 2025,
    primaryColor: "#0f172a",
    accentColor: "#3b82f6",
    heroImage: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2070"
  },
  posts: [
    {
      id: "1",
      title: "차세대 배터리 칠러 모듈화 공정 고도화 성공",
      content: "자체 개발한 스마트 자동화 라인을 통해 배터리 칠러 부품의 조립 정밀도를 비약적으로 향상시켰습니다. 미래 모빌리티 시장을 향한 핵심 생산 기지로서의 입지를 강화합니다.",
      date: "2025-01-20",
      category: "Innovation",
      imageUrl: "https://images.unsplash.com/photo-1565608438257-fac3c27beb36?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: "2",
      title: "친환경 고기능성 표면처리 자동화 설비 도입",
      content: "내구성 향상을 위한 특수 도장 공정을 자동화 설비로 전면 전환하여, 품질의 상향 평준화와 작업 환경 개선을 동시에 실현했습니다.",
      date: "2025-02-05",
      category: "Technology",
      imageUrl: "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=1000"
    }
  ],
  settings: {
    seoTitle: "와이크로시스템즈 | 배터리·오일 칠러 표면처리 & 모듈화 생산 솔루션",
    seoDescription: "독보적인 자동화 설비 기술력 기반, 전기차 배터리/오일 칠러 부품의 표면처리 및 모듈화 생산 전문 기업 와이크로시스템즈입니다.",
    socialLinks: {
      linkedin: "https://linkedin.com",
      blog: "https://blog.naver.com"
    },
    theme: ThemeMode.MODERN
  }
};
