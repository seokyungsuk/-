
import React, { useState } from 'react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  companyEmail: string;
}

const InquiryModal: React.FC<Props> = ({ isOpen, onClose, companyEmail }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    company: '',
    subject: '배터리·오일 칠러 부품 표면처리(도장)',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const FORMSPREE_URL = "https://formspree.io/f/xlgwrnrj";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch(FORMSPREE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          phone: formData.phone,
          company: formData.company,
          type: formData.subject,
          message: formData.message,
          _subject: `[와이크로시스템즈 문의] ${formData.name}님으로부터 새로운 상담 신청`
        })
      });

      if (response.ok) {
        setIsSuccess(true);
        setFormData({ name: '', phone: '', company: '', subject: '배터리·오일 칠러 부품 표면처리(도장)', message: '' });
        setTimeout(() => {
          setIsSuccess(false);
          onClose();
        }, 3000);
      } else {
        throw new Error('서버 전송에 실패했습니다.');
      }
    } catch (err) {
      setError('죄송합니다. 전송 중 오류가 발생했습니다. 잠시 후 다시 시도해 주세요.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" 
        onClick={onClose}
      ></div>
      
      <div className="bg-white w-full max-w-xl rounded-[40px] overflow-hidden shadow-2xl relative z-10 transform transition-all animate-fade-in">
        {isSuccess ? (
          <div className="p-16 text-center">
            <div className="w-20 h-20 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4 tracking-tight">상담 접수 완료</h2>
            <p className="text-slate-500 font-medium">문의하신 내용이 담당자에게 전달되었습니다.<br/>빠른 시일 내에 연락드리겠습니다.</p>
          </div>
        ) : (
          <div className="p-10 md:p-12">
            <div className="flex justify-between items-start mb-10">
              <div>
                <span className="text-blue-600 font-extrabold tracking-[0.3em] text-[10px] uppercase mb-2 block">Consultation Request</span>
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">상담 신청서</h2>
              </div>
              <button 
                onClick={onClose}
                className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-all"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">성함 *</label>
                  <input 
                    required
                    type="text" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    placeholder="홍길동"
                    className="w-full bg-slate-50 border border-transparent rounded-2xl px-5 py-4 focus:bg-white focus:border-blue-500 outline-none transition-all text-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">연락처 *</label>
                  <input 
                    required
                    type="tel" 
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                    placeholder="010-0000-0000"
                    className="w-full bg-slate-50 border border-transparent rounded-2xl px-5 py-4 focus:bg-white focus:border-blue-500 outline-none transition-all text-sm font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">회사명 (선택)</label>
                <input 
                  type="text" 
                  value={formData.company}
                  onChange={e => setFormData({...formData, company: e.target.value})}
                  placeholder="주식회사 와이크로시스템즈"
                  className="w-full bg-slate-50 border border-transparent rounded-2xl px-5 py-4 focus:bg-white focus:border-blue-500 outline-none transition-all text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">문의유형</label>
                <select 
                  value={formData.subject}
                  onChange={e => setFormData({...formData, subject: e.target.value})}
                  className="w-full bg-slate-50 border border-transparent rounded-2xl px-5 py-4 focus:bg-white focus:border-blue-500 outline-none transition-all text-sm font-medium appearance-none"
                >
                  <option>배터리·오일 칠러 부품 표면처리(도장)</option>
                  <option>칠러 부품 모듈화 생산 및 양산</option>
                  <option>맞춤형 자동화 설비 설계 및 제작</option>
                  <option>기술 협력 및 기타 문의</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">문의내용 *</label>
                <textarea 
                  required
                  rows={4}
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                  placeholder="상세한 문의 내용을 남겨주시면 빠르게 답변 드리겠습니다."
                  className="w-full bg-slate-50 border border-transparent rounded-2xl px-5 py-4 focus:bg-white focus:border-blue-500 outline-none transition-all text-sm font-medium resize-none"
                />
              </div>

              {error && (
                <p className="text-red-500 text-xs font-bold text-center">{error}</p>
              )}

              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 hover:bg-slate-900 text-white py-5 rounded-2xl font-bold text-lg shadow-xl shadow-blue-600/20 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    상담 신청하기
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="ml-1"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default InquiryModal;
