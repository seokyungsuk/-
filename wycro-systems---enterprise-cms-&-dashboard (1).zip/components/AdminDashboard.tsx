
import React, { useState } from 'react';
import { AppState, Post } from '../types';

interface Props {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  activeTab: 'content' | 'posts' | 'settings';
  setActiveTab: (tab: 'content' | 'posts' | 'settings') => void;
}

const AdminDashboard: React.FC<Props> = ({ state, setState, activeTab, setActiveTab }) => {
  const [newPost, setNewPost] = useState<Partial<Post>>({
    title: '',
    content: '',
    category: 'News',
    date: new Date().toISOString().split('T')[0]
  });

  const updateContent = (key: keyof AppState['content'], value: any) => {
    setState(prev => ({
      ...prev,
      content: { ...prev.content, [key]: value }
    }));
  };

  const updateSettings = (key: keyof AppState['settings'], value: any) => {
    setState(prev => ({
      ...prev,
      settings: { ...prev.settings, [key]: value }
    }));
  };

  const handleAddPost = () => {
    if (!newPost.title || !newPost.content) return;
    const post: Post = {
      id: Date.now().toString(),
      title: newPost.title,
      content: newPost.content,
      category: newPost.category || 'News',
      date: newPost.date || new Date().toISOString().split('T')[0],
      imageUrl: newPost.imageUrl
    };
    setState(prev => ({
      ...prev,
      posts: [post, ...prev.posts]
    }));
    setNewPost({ title: '', content: '', category: 'News', date: new Date().toISOString().split('T')[0] });
  };

  const handleDeletePost = (id: string) => {
    setState(prev => ({
      ...prev,
      posts: prev.posts.filter(p => p.id !== id)
    }));
  };

  return (
    <div className="flex h-screen bg-slate-900 text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 bg-slate-950 flex flex-col p-6 border-r border-slate-800">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-black">W</div>
          <div>
            <h2 className="text-sm font-bold tracking-tight">WYCRO CMS</h2>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Management v1.0</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          <button 
            onClick={() => setActiveTab('content')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'content' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" x2="4" y1="22" y2="15"/></svg>
            콘텐츠 관리
          </button>
          <button 
            onClick={() => setActiveTab('posts')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'posts' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            게시글(뉴스)
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'settings' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
            시스템 설정
          </button>
        </nav>

        <div className="mt-auto bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Logged in as</p>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-slate-700 rounded-full flex items-center justify-center text-[10px]">AD</div>
            <p className="text-xs font-medium">Administrator</p>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-12 custom-scrollbar">
        <header className="mb-12 flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              {activeTab === 'content' && '콘텐츠 커스터마이징'}
              {activeTab === 'posts' && '게시글 라이브러리'}
              {activeTab === 'settings' && 'SEO 및 시스템 설정'}
            </h1>
            <p className="text-slate-400">웹사이트의 모든 정보를 실시간으로 수정하고 발행할 수 있습니다.</p>
          </div>
          <div className="flex items-center gap-3 bg-slate-800 px-4 py-2 rounded-lg text-xs font-medium text-slate-300">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            System Synchronized
          </div>
        </header>

        {activeTab === 'content' && (
          <div className="max-w-4xl space-y-10">
            <section className="bg-slate-800/40 border border-slate-800 rounded-3xl p-8">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                <span className="w-1 h-6 bg-blue-500 rounded-full"></span>
                기본 정보
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">회사명 (한글)</label>
                  <input 
                    type="text" 
                    value={state.content.companyName}
                    onChange={e => updateContent('companyName', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">회사명 (영문)</label>
                  <input 
                    type="text" 
                    value={state.content.companyNameEn}
                    onChange={e => updateContent('companyNameEn', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">메인 슬로건</label>
                  <input 
                    type="text" 
                    value={state.content.greetingTitle}
                    onChange={e => updateContent('greetingTitle', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">인사말 본문</label>
                  <textarea 
                    rows={8}
                    value={state.content.greetingContent}
                    onChange={e => updateContent('greetingContent', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all resize-none"
                  />
                </div>
              </div>
            </section>

            <section className="bg-slate-800/40 border border-slate-800 rounded-3xl p-8">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                <span className="w-1 h-6 bg-blue-500 rounded-full"></span>
                연락처 및 주소
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">대표번호</label>
                  <input 
                    type="text" 
                    value={state.content.phone}
                    onChange={e => updateContent('phone', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">이메일</label>
                  <input 
                    type="email" 
                    value={state.content.email}
                    onChange={e => updateContent('email', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">소재지 주소</label>
                  <input 
                    type="text" 
                    value={state.content.address}
                    onChange={e => updateContent('address', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none transition-all"
                  />
                </div>
              </div>
            </section>
          </div>
        )}

        {activeTab === 'posts' && (
          <div className="grid lg:grid-cols-3 gap-10">
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-slate-800/40 border border-slate-800 rounded-3xl p-8 sticky top-0">
                <h3 className="text-lg font-bold mb-6">새 게시글 작성</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">카테고리</label>
                    <select 
                      value={newPost.category}
                      onChange={e => setNewPost({...newPost, category: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm"
                    >
                      <option>News</option>
                      <option>Event</option>
                      <option>Notice</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">제목</label>
                    <input 
                      type="text" 
                      value={newPost.title}
                      onChange={e => setNewPost({...newPost, title: e.target.value})}
                      placeholder="게시글 제목을 입력하세요"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">이미지 URL (선택)</label>
                    <input 
                      type="text" 
                      value={newPost.imageUrl}
                      onChange={e => setNewPost({...newPost, imageUrl: e.target.value})}
                      placeholder="https://..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">내용</label>
                    <textarea 
                      rows={5}
                      value={newPost.content}
                      onChange={e => setNewPost({...newPost, content: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm resize-none"
                    />
                  </div>
                  <button 
                    onClick={handleAddPost}
                    className="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-xl font-bold transition-all shadow-xl shadow-blue-600/20"
                  >
                    게시글 발행
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-4">
              {state.posts.map(post => (
                <div key={post.id} className="bg-slate-800/20 border border-slate-800 rounded-2xl p-6 flex gap-6 items-center">
                  <div className="w-24 h-24 bg-slate-900 rounded-xl overflow-hidden shrink-0 border border-slate-700">
                    <img src={post.imageUrl || 'https://picsum.photos/200'} className="w-full h-full object-cover grayscale" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">{post.category}</span>
                      <span className="text-[10px] text-slate-500">•</span>
                      <span className="text-[10px] text-slate-500">{post.date}</span>
                    </div>
                    <h4 className="font-bold text-slate-100 truncate mb-1">{post.title}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2">{post.content}</p>
                  </div>
                  <button 
                    onClick={() => handleDeletePost(post.id)}
                    className="w-10 h-10 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-full flex items-center justify-center transition-all shrink-0"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-4xl space-y-8">
            <section className="bg-slate-800/40 border border-slate-800 rounded-3xl p-8">
              <h3 className="text-lg font-bold mb-6">검색 최적화 (SEO)</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-widest">Page Title</label>
                  <input 
                    type="text" 
                    value={state.settings.seoTitle}
                    onChange={e => updateSettings('seoTitle', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-widest">Meta Description</label>
                  <textarea 
                    rows={3}
                    value={state.settings.seoDescription}
                    onChange={e => updateSettings('seoDescription', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </section>

            <section className="bg-slate-800/40 border border-slate-800 rounded-3xl p-8">
              <h3 className="text-lg font-bold mb-6">SNS 연동</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-widest">LinkedIn URL</label>
                  <input 
                    type="text" 
                    value={state.settings.socialLinks.linkedin || ''}
                    onChange={e => updateSettings('socialLinks', { ...state.settings.socialLinks, linkedin: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-widest">Naver Blog URL</label>
                  <input 
                    type="text" 
                    value={state.settings.socialLinks.blog || ''}
                    onChange={e => updateSettings('socialLinks', { ...state.settings.socialLinks, blog: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 focus:outline-none"
                    placeholder="https://..."
                  />
                </div>
              </div>
            </section>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
