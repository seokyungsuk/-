
import React from 'react';
import { AppState } from '../types';

interface Props {
  state: AppState;
  onNavigate: (view: 'home' | 'greetings', sectionId?: string) => void;
  onAdminPosts: () => void;
  onInquiry: () => void;
}

const WebsiteHome: React.FC<Props> = ({ state, onNavigate, onAdminPosts, onInquiry }) => {
  const { content, posts } = state;

  return (
    <div className="bg-white selection:bg-blue-100">
      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-white/80 backdrop-blur-xl border-b border-slate-100 py-5 shadow-sm">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2.5 cursor-pointer group" onClick={() => onNavigate('home')}>
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold group-hover:scale-105 transition-transform">W</div>
            <span className="text-xl font-extrabold font-montserrat tracking-tighter text-slate-900 uppercase">
              {content.companyNameEn}
            </span>
          </div>
          <div className="hidden md:flex gap-10 text-[14px] font-semibold text-slate-500">
            <button onClick={() => onNavigate('greetings')} className="hover:text-blue-600 transition-colors uppercase tracking-widest">Company</button>
            <button onClick={() => onNavigate('home', 'features')} className="hover:text-blue-600 transition-colors uppercase tracking-widest">Business</button>
            <button onClick={() => onNavigate('home', 'contact')} className="hover:text-blue-600 transition-colors uppercase tracking-widest">Contact</button>
          </div>
          <button 
            onClick={onInquiry}
            className="bg-slate-900 text-white px-7 py-2.5 rounded-full text-sm font-bold hover:bg-blue-600 transition-all shadow-lg shadow-slate-900/10 active:scale-95"
          >
            상담문의
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[100vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={content.heroImage} 
            className="w-full h-full object-cover brightness-[0.4] scale-100" 
            alt="Hero background" 
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent"></div>
        </div>
        <div className="container mx-auto px-6 relative z-10 text-white">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-full mb-8 animate-fade-up">
              <span className="w-1.5 h-1.5 bg-blue-400 rounded-full"></span>
              <span className="text-[10px] font-bold tracking-[0.25em] uppercase text-blue-100">Future Mobility Pioneer</span>
            </div>
            {/* 폰트 크기를 줄이고 줄바꿈과 행간을 세련되게 조정 */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.2] mb-8 animate-fade-up whitespace-pre-wrap tracking-tight">
              {content.greetingTitle}
            </h1>
            <p className="text-base md:text-xl text-slate-300 mb-10 leading-relaxed font-light max-w-2xl animate-fade-up [animation-delay:200ms] text-balance">
              와이크로시스템즈는 기술의 본질을 이해하는 자동화 솔루션으로 완벽한 표면처리와 정밀 모듈화 공정을 실현합니다.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-up [animation-delay:400ms]">
              <button 
                onClick={() => onNavigate('greetings')}
                className="px-10 py-4 bg-blue-600 hover:bg-blue-700 transition-all rounded-full font-bold shadow-xl shadow-blue-500/30 text-sm flex items-center justify-center group"
              >
                상세 정보
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="ml-2 group-hover:translate-x-1 transition-transform"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
              </button>
              <button 
                onClick={() => onNavigate('home', 'contact')}
                className="px-10 py-4 bg-white/5 hover:bg-white/10 transition-all backdrop-blur-md border border-white/20 rounded-full font-bold text-sm"
              >
                오시는길
              </button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-12 left-6 md:left-12 z-10 hidden md:block animate-fade-up [animation-delay:800ms]">
            <div className="flex items-center gap-5 text-[10px] font-bold tracking-[0.3em] text-slate-400 uppercase opacity-60">
                <span>Precision</span>
                <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                <span>Automation</span>
                <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                <span>Production</span>
            </div>
        </div>
      </section>

      {/* Features / Services */}
      <section id="features" className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-24 gap-10">
            <div className="max-w-3xl">
              <span className="text-blue-600 font-extrabold tracking-[0.3em] text-[10px] uppercase mb-4 block">Core Competencies</span>
              <h2 className="text-3xl md:text-5xl font-bold text-slate-900 leading-tight tracking-tight">완벽한 공정을 위한<br/>우리의 핵심 경쟁력</h2>
            </div>
            <p className="text-slate-500 text-base md:text-lg font-light max-w-sm leading-relaxed">
              설비 설계부터 최종 양산까지, 데이터와 기술로 증명하는 고도화된 생산 라인을 운영합니다.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                title: "Precision Coating", 
                label: "표면처리 솔루션",
                desc: "배터리 및 오일 칠러의 내구성과 방열성을 극대화하는 자동화 도장 공정으로 무결점 품질을 보장합니다.",
                icon: <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              },
              { 
                title: "Module Assembly", 
                label: "모듈화 생산",
                desc: "정밀 부품의 유기적인 조립을 위한 스마트 생산 라인을 통해 공정 효율과 생산성을 획기적으로 향상시킵니다.",
                icon: <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              },
              { 
                title: "Custom Equipment", 
                label: "설비 설계 및 제작",
                desc: "단순 제조를 넘어 각 고객사의 현장에 최적화된 맞춤형 자동화 설비를 설계하고 직접 생산 라인에 이식합니다.",
                icon: <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></svg>
              }
            ].map((f, i) => (
              <div key={i} className="group p-10 bg-slate-50 border border-slate-100 rounded-[40px] hover:bg-white hover:shadow-2xl hover:shadow-slate-200/50 transition-all duration-700 relative overflow-hidden">
                <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-blue-600 mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all duration-500 shadow-sm border border-slate-100">
                  {f.icon}
                </div>
                <span className="text-blue-600 font-bold text-[10px] uppercase tracking-widest mb-3 block">{f.label}</span>
                <h3 className="text-xl font-bold text-slate-900 mb-4 tracking-tight">{f.title}</h3>
                <p className="text-slate-500 leading-relaxed text-sm font-light">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* News/Posts Section */}
      <section id="posts" className="py-32 bg-slate-950 text-white overflow-hidden">
        <div className="container mx-auto px-6 relative">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div className="max-w-2xl">
              <span className="text-blue-500 font-extrabold tracking-[0.3em] text-[10px] uppercase mb-4 block">Inside Wycro</span>
              <h2 className="text-3xl md:text-5xl font-bold mb-4 tracking-tight">혁신은 매일<br/>현장에서 일어납니다</h2>
            </div>
            <button onClick={onAdminPosts} className="text-[11px] font-bold border-b border-blue-600 pb-2 hover:text-blue-400 transition-colors uppercase tracking-[0.2em] mb-4">View All News</button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-12">
            {posts.map(post => (
              <article key={post.id} className="group cursor-pointer flex flex-col md:flex-row gap-8 items-start">
                <div className="relative overflow-hidden rounded-[32px] aspect-[4/3] w-full md:w-64 shrink-0">
                  <img 
                    src={post.imageUrl || `https://picsum.photos/seed/${post.id}/800/600`} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000 brightness-75 group-hover:brightness-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                </div>
                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="bg-blue-600/20 text-blue-400 text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest">{post.category}</span>
                    <span className="text-slate-600 font-montserrat text-[10px] font-bold uppercase tracking-widest">{post.date}</span>
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold mb-4 group-hover:text-blue-400 transition-colors leading-tight tracking-tight">{post.title}</h3>
                  <p className="text-slate-400 line-clamp-2 font-light leading-relaxed text-sm mb-6">{post.content}</p>
                  <div className="flex items-center text-blue-500 font-bold text-xs group-hover:gap-2 transition-all">
                    자세히 보기
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="ml-1.5"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Map & Contact */}
      <section id="contact" className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-24 items-center">
            <div>
              <span className="text-blue-600 font-extrabold tracking-[0.3em] text-[10px] uppercase mb-4 block">Global Network</span>
              <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-16 tracking-tight">공정의 혁신,<br/>지금 바로 문의하십시오</h2>
              <div className="space-y-12">
                {[
                  { label: "Address", val: content.address, icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="12" r="3"/></svg> },
                  { label: "Phone", val: content.phone, icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg> },
                  { label: "E-mail", val: content.email, icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg> }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-8 group">
                    <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center shrink-0 group-hover:bg-slate-900 group-hover:text-white transition-all duration-500 shadow-sm border border-slate-100">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-slate-400 text-[9px] font-black uppercase tracking-[0.2em] mb-2">{item.label}</p>
                      <p className="text-slate-900 font-bold text-lg tracking-tight">{item.val}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-[48px] overflow-hidden shadow-2xl h-[550px] bg-slate-100 relative group border-[10px] border-white ring-1 ring-slate-100">
              <iframe 
                width="100%" 
                height="100%" 
                frameBorder="0" 
                scrolling="no" 
                src={`https://maps.google.com/maps?q=${encodeURIComponent(content.address)}&t=&z=16&ie=UTF8&iwloc=&output=embed`}
                className="w-full h-full grayscale-[0.1]" 
                title="Google Map"
              ></iframe>
              <div className="absolute top-8 left-8 bg-white/90 backdrop-blur-xl px-6 py-4 rounded-[24px] shadow-xl border border-white/50">
                <p className="text-[9px] font-bold uppercase text-blue-600 tracking-[0.2em] mb-1">HQ Location</p>
                <p className="text-slate-900 font-bold text-base">와이크로시스템즈</p>
              </div>
              <a 
                href={`https://map.naver.com/v5/search/${encodeURIComponent(content.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute bottom-8 right-8 bg-slate-900 text-white px-8 py-4 rounded-full text-xs font-bold shadow-2xl hover:bg-blue-600 transition-all flex items-center gap-2.5 active:scale-95"
              >
                네이버 지도로 길찾기
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-50 py-24 border-t border-slate-100">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start gap-16">
            <div className="max-w-md">
              <div className="flex items-center gap-2.5 mb-8">
                <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white text-xs font-black">W</div>
                <span className="text-xl font-extrabold font-montserrat tracking-tighter text-slate-900 uppercase">
                  {content.companyNameEn}
                </span>
              </div>
              <div className="space-y-2 mb-8 text-slate-500 text-sm font-medium">
                <p className="text-slate-900 font-bold">{content.companyName}</p>
                <p>{content.address}</p>
                <p className="font-montserrat">{content.phone} / {content.email}</p>
              </div>
              <p className="text-slate-400 text-[10px] font-bold tracking-[0.2em] uppercase">© {new Date().getFullYear()} {content.companyNameEn}. All Rights Reserved.</p>
            </div>
            <div className="flex gap-4">
              {[
                { name: 'LinkedIn', icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>, link: state.settings.socialLinks.linkedin },
                { name: 'Blog', icon: <span className="font-black text-[9px] tracking-tighter leading-none text-center">BLOG</span>, link: state.settings.socialLinks.blog }
              ].map((social, i) => social.link && (
                <a key={i} href={social.link} className="w-14 h-14 bg-white border border-slate-200 rounded-[20px] flex items-center justify-center text-slate-400 hover:text-blue-600 hover:border-blue-200 hover:shadow-xl transition-all active:scale-90">
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WebsiteHome;
