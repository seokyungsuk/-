
import React from 'react';
import { AppState } from '../types';

interface Props {
  state: AppState;
  onNavigate: (view: 'home' | 'greetings', sectionId?: string) => void;
  onAdminPosts: () => void;
  onInquiry: () => void;
}

const GreetingsPage: React.FC<Props> = ({ state, onNavigate, onAdminPosts, onInquiry }) => {
  const { content } = state;

  return (
    <div className="bg-white selection:bg-blue-100 min-h-screen flex flex-col">
      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 py-4 shadow-sm">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">W</div>
            <span className="text-xl font-bold font-montserrat tracking-tight text-slate-900 uppercase">
              {content.companyNameEn}
            </span>
          </div>
          <div className="hidden md:flex gap-8 text-sm font-medium text-slate-600">
            <button onClick={() => onNavigate('home')} className="hover:text-blue-600 transition-colors">홈으로</button>
            <button onClick={() => onNavigate('greetings')} className="text-blue-600 font-bold border-b-2 border-blue-600">회사소개</button>
            <button onClick={() => onNavigate('home', 'features')} className="hover:text-blue-600 transition-colors">주요사업</button>
            <button onClick={() => onNavigate('home', 'contact')} className="hover:text-blue-600 transition-colors">오시는길</button>
          </div>
          <button 
            onClick={onInquiry}
            className="bg-slate-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-blue-600 transition-all shadow-md text-center"
          >
            상담문의
          </button>
        </div>
      </nav>

      {/* Sub Hero / Page Title */}
      <header className="pt-48 pb-24 bg-slate-50 border-b border-slate-100">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <span className="text-blue-600 font-bold tracking-widest text-xs uppercase mb-4 block">About Us</span>
            <h1 className="text-5xl md:text-7xl font-bold text-slate-900 leading-tight mb-8">
              COMPANY INTRO
            </h1>
            <p className="text-xl text-slate-500 font-light leading-relaxed">
              와이크로시스템즈는 기술 기반의 제조 혁신을 통해<br/>
              대한민국 자동화 설비의 새로운 기준을 제시합니다.
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 py-32">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-16 leading-tight">
              “공정을 이해하는 설비 회사,<br/>
              설비를 만드는 제조기업”
            </h2>
            <div className="space-y-12 text-slate-600 leading-relaxed text-xl whitespace-pre-wrap font-light">
              {content.greetingContent}
            </div>
            
            <div className="mt-24 pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-8">
              <div>
                <p className="text-slate-400 text-sm font-medium mb-2 uppercase tracking-widest">Chief Executive Officer</p>
                <p className="text-slate-900 text-3xl font-bold">와이크로시스템즈 임직원 일동</p>
              </div>
              <div className="bg-slate-50 px-8 py-6 rounded-2xl border border-slate-100">
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Established</p>
                <p className="text-slate-900 text-4xl font-black font-montserrat">{content.establishedYear}</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Corporate Identity Section */}
      <section className="py-32 bg-slate-900 text-white">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-blue-500 font-bold tracking-widest text-xs uppercase mb-16 block">Our Core Values</h3>
          <div className="grid md:grid-cols-3 gap-16">
            <div>
              <p className="text-5xl font-black font-montserrat text-blue-600 mb-6 opacity-50">01</p>
              <h4 className="text-2xl font-bold mb-4">Innovation</h4>
              <p className="text-gray-400 font-light leading-relaxed">자체 설비 운영 경험을 바탕으로 공정의 사소한 불편함까지 해결하는 혁신을 추구합니다.</p>
            </div>
            <div>
              <p className="text-5xl font-black font-montserrat text-blue-600 mb-6 opacity-50">02</p>
              <h4 className="text-2xl font-bold mb-4">Trust</h4>
              <p className="text-gray-400 font-light leading-relaxed">고객사의 원가 절감과 생산성 향상을 최우선으로 생각하는 신뢰받는 파트너가 되겠습니다.</p>
            </div>
            <div>
              <p className="text-5xl font-black font-montserrat text-blue-600 mb-6 opacity-50">03</p>
              <h4 className="text-2xl font-bold mb-4">Quality</h4>
              <p className="text-gray-400 font-light leading-relaxed">배터리·오일 냉각기(칠러) 부품 도장·모듈화 자동화 생산라인</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer (Simplified for this view) */}
      <footer className="bg-slate-50 py-24 border-t border-slate-100">
        <div className="container mx-auto px-6 text-center md:text-left">
          <div className="flex flex-col md:flex-row justify-between items-center md:items-start gap-12">
            <div>
              <div className="flex items-center justify-center md:justify-start gap-3 mb-8" onClick={() => onNavigate('home')}>
                <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white text-xs font-black">W</div>
                <span className="text-xl font-bold font-montserrat tracking-tighter text-slate-900 uppercase">
                  {content.companyNameEn}
                </span>
              </div>
              <div className="space-y-2 mb-8">
                <p className="text-slate-900 font-bold text-sm">{content.companyName}</p>
                <p className="text-slate-500 text-sm max-w-sm leading-relaxed">{content.address}</p>
                <p className="text-slate-500 text-sm">{content.phone} | {content.email}</p>
              </div>
              <p className="text-slate-400 text-[10px] font-bold tracking-widest uppercase">© {new Date().getFullYear()} {content.companyNameEn}. All Rights Reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default GreetingsPage;
