
export enum ThemeMode {
  LIGHT = 'light',
  DARK = 'dark',
  MODERN = 'modern'
}

export interface SiteContent {
  companyName: string;
  companyNameEn: string;
  greetingTitle: string;
  greetingContent: string;
  phone: string;
  address: string;
  email: string;
  establishedYear: number;
  primaryColor: string;
  accentColor: string;
  heroImage: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  date: string;
  category: string;
  imageUrl?: string;
}

export interface SiteSettings {
  seoTitle: string;
  seoDescription: string;
  socialLinks: {
    instagram?: string;
    facebook?: string;
    linkedin?: string;
    blog?: string;
  };
  theme: ThemeMode;
}

export interface AppState {
  content: SiteContent;
  posts: Post[];
  settings: SiteSettings;
}
